package com.s2C3S.main;

import java.util.Vector;

import com.s2C3S.trainS.s2C3S;
import com.s2C3S.utils.LoadDataUtil;
import com.s2C3S.utils.ParametersUtil;

/**
 * @ClassName: RunMethod
 * @Description: Entry our method
 * @author Dr. Yunlong Mi
 * @date Jan. 23, 2022; Apr. 14, 2023
 * @version A semi-supervised concept-cognitive computing system for dynamic
			classification decision making with limited feedback information. 
			之前预测是类别，这个版本预测可以出现预测概率。可以用于AUC之类的计算。
 *          (1)conceptSTM被注释，可能对精度有影响[1.1.2021.09_ConceptDL_release存在]
 *          (2)loadData2不排序与loadData排序也对学习的精度亦有影响 (3)添加 label information 与
 *          concept similarity and label information <br/>
 * @since jdk1.8
 */
public class RunMethod {

	public static void main(String[] args) throws Exception {
		/** Loop 20 times */
		for (int index = 1; index <= 20; ++index) {
			/** Load datasets */
			long s1 = System.currentTimeMillis();
			Vector<Object> train_vec = LoadDataUtil
					.loadData(ParametersUtil.train_path.replace("indexNum", String.valueOf(index)));
			// Vector<Object> train_vec = LoadDataUtil.load2Data(
			// ParametersUtil.train_path.replace("indexNum", String.valueOf(index)),
			// ParametersUtil.validation_path.replace("indexNum", String.valueOf(index)));
			Vector<Object> test_vec = LoadDataUtil
					.loadData2(ParametersUtil.test_path.replace("indexNum", String.valueOf(index)));
			long e1 = System.currentTimeMillis();
			System.err.println("Load dataset：" + (e1 - s1) + "(ms)");

			/** Instantiation system, 实例化系统 */
			s2C3S C3S = new s2C3S(train_vec, train_vec);
			/** Initial system, 系统初始化 */
			long s2 = System.currentTimeMillis();
			C3S.initialS();
			long e2 = System.currentTimeMillis();
			System.err.println("Initial system：" + (e2 - s2) + "(ms)");

			/** Learning for system, 系统学习 */
			long s3 = System.currentTimeMillis();
			C3S.trainS();
			long e3 = System.currentTimeMillis();
			System.err.println("Training system：" + (e3 - s3) + "(ms)");

			/** Evaluating and updating system, 系统动态更新与评估 */
			long s4 = System.currentTimeMillis();
			C3S.evaluateS(test_vec, index);
			long e4 = System.currentTimeMillis();
			System.err.println("Evaluating system：" + (e4 - s4) + "(ms)");
		} // end_of_for_20_loops
	}// end_of_main
}
