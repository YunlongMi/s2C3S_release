package com.s2C3S.initialS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.RecursiveTask;

import com.s2C3S.utils.ParametersUtil;

import java.util.Set;
import java.util.Vector;

/**
 * @ClassName: InitalMethod
 * @Description: Constructing initial concept spaces by theta
 * @author Yunlong.MI
 * @date Sep.,30 2019
 * @version
 * @since jdk1.8
 */
public class InitalMethod {
	private Vector<Object> train_vec;

	public InitalMethod(Vector<Object> train_vec) {
		this.train_vec = train_vec;
	}

	/**
	 * @return Vector<Object>
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 * @details Constructing concept spaces by different theta threshold value
	 */
	@SuppressWarnings("unchecked")
	public Vector<Object> initialConceptPoolByTheta() throws IOException, InterruptedException, ExecutionException {
		double[][] train_X = (double[][]) train_vec.get(0);// instances without label information
		HashMap<Integer, Integer> train_CY = (HashMap<Integer, Integer>) train_vec.get(2);// class space information
		ForkJoinPool forkJoinPool = new ForkJoinPool();// invokes Fork/Join framework
		Future<Vector<Object>> future = null;

		if (ParametersUtil.P == 1) {// the initial theta being consistent with the end
			int theta_start = ParametersUtil.lambda, theta_end = ParametersUtil.lambda;
			future = forkJoinPool.submit(new ConstructConceptPoolTask(train_X, train_CY, theta_start, theta_end));
		} else if (ParametersUtil.P == 0.1) {// concept falling P= 1/n
			int theta_start = 1, theta_end = 10;
			future = forkJoinPool.submit(new ConstructConceptPoolTask(train_X, train_CY, theta_start, theta_end));
		} // end_of_if
		Vector<Object> vec = future.get();// get(0): concept pool
		forkJoinPool.shutdown();
		train_vec = null;// clear memory
		return vec;
	}// end_of_InitialConceptPoolByTheta

	/**
	 * @className ConstructConceptPoolTask
	 * @details 继承RecursiveAction来实现“可分解”的任务
	 */
	class ConstructConceptPoolTask extends RecursiveTask<Vector<Object>> {
		private static final long serialVersionUID = 1L;
		private double[][] train_X;
		private HashMap<Integer, Integer> train_CY;
		private int theta_start, theta_end;
		private static final int MAX = 1;// step size: 1.0/10=0.1

		ConstructConceptPoolTask(double[][] train_X, HashMap<Integer, Integer> train_CY, int theta_start,
				int theta_end) {
			this.train_X = train_X;
			this.train_CY = train_CY;
			this.theta_start = theta_start;
			this.theta_end = theta_end;
		}// end_of_ConstructConceptPoolTask

		/** @details: collects all concepts into a concept pool by different theta */
		@SuppressWarnings("unchecked")
		@Override
		protected Vector<Object> compute() {// for theta_start = theta_end
			List<Map<double[], Set<Integer>>> conceptList = new ArrayList<Map<double[], Set<Integer>>>();// 局部变量，每次调用都是独立的。
			if ((theta_end - theta_start) < MAX) {
				for (int a = theta_start; a <= theta_end; ++a) {
					/** Construct concept space */
					double theta = (double) a / 10;// suppresses theta into [0.0,1.0]
					double[][] tempX = train_X;// copy instances
					HashMap<Integer, Integer> tempCY = train_CY;// copy label space
					try {
						GetConceptSpace gcs = new GetConceptSpace();
						conceptList = gcs.getConceptSpace(tempX, tempCY, theta);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				} // end_of_for
				Vector<Object> vec = new Vector<Object>();
				vec.add(conceptList);// gets the concept spaces
				return vec;
			} else {// for theta_end being greater than theta_start
				int middle = (theta_start + theta_end) / 2;
				ConstructConceptPoolTask left = new ConstructConceptPoolTask(train_X, train_CY, theta_start, middle);
				ConstructConceptPoolTask right = new ConstructConceptPoolTask(train_X, train_CY, middle + 1, theta_end);
				left.fork();
				right.fork();
				left.join();
				right.join();
				/** Combining two results */
				Vector<Object> vec = new Vector<Object>();
				List<Map<Set<Integer>, double[]>> rList = (List<Map<Set<Integer>, double[]>>) right.getRawResult()
						.get(0);
				List<Map<Set<Integer>, double[]>> lList = (List<Map<Set<Integer>, double[]>>) left.getRawResult()
						.get(0);
				for (int i = 0; i < rList.size(); ++i) {
					rList.get(i).putAll(lList.get(i)); // putAll:有相同的 key 会覆盖之前 value, 没有就会合并
				} // end_of_for
				vec.add(rList);
				return vec;
			} // end_of_if_Max
		}// end_of_compute
	}// end_of_class_ConstructConceptPoolTask
}
