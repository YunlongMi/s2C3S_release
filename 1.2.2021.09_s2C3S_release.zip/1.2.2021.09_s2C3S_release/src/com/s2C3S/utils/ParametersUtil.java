package com.s2C3S.utils;

/**
 * @ClassName: PropertiesUtil
 * @Description: Set the related parameters.
 * @author Dr. Mi
 * @date Sep. 12, 2021
 * @since jdk1.8
 */
public class ParametersUtil {
	/** A demo example, a training and testing from Training 10% of SZCXR. */
	// public static String train_path = "./data/train[1].csv";
	// public static String test_path = "./data/test[1].csv";
	// public static String train_path =
	// "D:/数据信息/DataStream/real-word/COVID-19_Radiography/ours/20%training_VGG/train[indexNum].csv";
	// public static String validation_path =
	// "D:/数据信息/DataStream/real-word/COVID-19_Radiography/ours/20%training_VGG/train[indexNum].csv";
	// public static String test_path =
	// "D:/数据信息/DataStream/real-word/COVID-19_Radiography/ours/20%training_VGG/test[indexNum].csv";

	// public static String train_path =
	// "D:/数据信息/DataStream/real-word/HAR/ours/20%training/train[indexNum].csv";
	// public static String validation_path =
	// "D:/数据信息/DataStream/real-word/HAR/ours/20%training/train[indexNum].csv";
	// public static String test_path =
	// "D:/数据信息/DataStream/real-word/HAR/ours/20%training/test[indexNum].csv";

	public static String train_path = "D:/数据信息/DataStream/real-word/Mnist/ours/10%training[0-1]/train[indexNum].csv";
	public static String validation_path = "D:/数据信息/DataStream/real-word/Mnist/ours/10%training[0-1]/train[indexNum].csv";
	public static String test_path = "D:/数据信息/DataStream/real-word/Mnist/ours/10%training[0-1]/test[indexNum].csv";

	// public static String train_path =
	// "D:/数据信息/DataStream/real-word/mushroom/ours/10%training[val]/train[indexNum].csv";
	// public static String validation_path =
	// "D:/数据信息/DataStream/real-word/mushroom/ours/10%training[val]/validation[indexNum].csv";
	// public static String test_path =
	// "D:/数据信息/DataStream/real-word/mushroom/ours/10%training[val]/test[indexNum].csv";

	public static String methodType = "conceptCS";
	/** Show the results by bachSize or overall accuracies. */
	public static String showResult = "overall";// bachSize or overall

	/** Fixed Lambda(i): concept falling space, the $\lambda $ value and P */
	public static int lambda = 8; // it represents lambda = 8/10
	public static double P = 1;// concept falling, P=1 or P=0.1
	/** Epsion cocnept */
	public static double e = 0.7;// it means the similarity of two samples, CosineDistance [0,1].
	/** MaxSize: The size of concept spaces for each class. */
	public static int conceptSZ = 3000;
	/** Chunk size: The size of each data chunk. */
	public static int C = 100;

	/** Fixed radius r: the radius of miro-cluster. */
	public static double r = 0.9;
	/** Fixed delta: The range of the local subconcept space. default delta=5. */
	public static int delta = 5;// defalut: 5
}
