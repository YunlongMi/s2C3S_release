package com.s2C3S.utils;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * @ClassName: MetricMethodUtil
 * @Description: Metric method
 * @author Dr. Yunlong Mi
 * @date Jul. 10, 2020
 * @version
 * @since jdk1.8
 */
public class MathMethodUtil {
	/**
	 * @param ins1
	 * @param ins2
	 * @return 使用2范数，即欧式距离
	 */
	public static double getEuclideanDistance(double[] ins1, double[] ins2) {
		double result = 0.0;
		for (int i = 0; i < ins2.length; ++i) {
			result += Math.pow(ins1[i] - ins2[i], 2); // d12=sqrt[(x1-x2)^2+(y1-y2)^2]
		} // end_of_for
		return Math.sqrt(result);
	}// end_of_getEuclideanDistance

	/**
	 * @param ins1
	 * @param ins2
	 * @return 余弦距离
	 */
	public static double getCosineDistance(double[] ins1, double[] ins2) {
		double sum1 = 0.0, sum2 = 0.0, sum3 = 0.0;
		for (int i = 0; i < ins2.length; ++i) {
			sum1 += ins1[i] * ins2[i];
			sum2 += Math.pow(ins1[i], 2);
			sum3 += Math.pow(ins2[i], 2);
		} // end_of_for
		return sum1 / (Math.sqrt(sum2) * Math.sqrt(sum3));
	}// end_of_getCosineDistance

	/**
	 * @param ins1
	 * @param ins2
	 * @return 求均值
	 */
	public static double[] getAverageDistance(double[] ins1, double[] ins2) {
		double[] ins3 = new double[ins1.length];
		for (int i = 0; i < ins2.length; ++i) {
			ins3[i] = (ins1[i] + ins2[i]) / 2;
		} // end_of_for
		return ins3;
	}// end_of_getAverageDistance

	/**
	 * @param extent
	 * @param nextExtent
	 * @return 求并集
	 */
	public static Set<Integer> getSetUnion(Set<Integer> extent, Set<Integer> nextExtent) {
		TreeSet<Integer> resultSet = new TreeSet<Integer>();
		resultSet.addAll(extent);
		resultSet.addAll(nextExtent);
		return resultSet;
	}// end_of_getAverageDistance

	/**
	 * @param dataChunk
	 * @return array
	 */
	public static double[][] getMaptoArray(Map<double[], Set<Integer>> dataChunk) {
		double[][] arr = new double[dataChunk.size()][];
		Collection<double[]> valuesSet = dataChunk.keySet();
		int i = 0;
		for (double[] value : valuesSet) {
			arr[i] = value;
			++i;
		}
		return arr;
	}// end_of_getMaptoArray

	/**
	 * @param dataChunk
	 * @return array
	 */
	public static double[][] getMaptoArraybySize(Map<double[], Set<Integer>> dataChunk, int size) {
		double[][] arr = new double[size][];
		Collection<double[]> valuesSet = dataChunk.keySet();
		int i = 0;
		for (double[] value : valuesSet) {
			arr[i] = value;
			++i;
			if (i == size) {// if size=100, then arr.size=100.
				break;
			}
		}
		return arr;
	}// end_of_getMaptoArray

	/**
	 * @param arr
	 * @return a average vector from array
	 */
	public static double[] getAverageVectorfromArray(double[][] arr) {
		int dim = arr[0].length;// dimension
		double[] x = new double[dim];// define a vector for average value
		for (int j = 0; j < dim; ++j) {// column
			for (int k = 0; k < arr.length; ++k) {// row
				x[j] += arr[k][j];
			}
			x[j] = x[j] / arr.length;
		}
		return x;
	}// end_of_getAverageVectorfromArray

}
