package com.s2C3S.evaluateS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

import com.s2C3S.commonTools.ConComSimilarityByInsParLab;
import com.s2C3S.commonTools.GetNewConcepts;
import com.s2C3S.commonTools.UpdateConceptSpace;
import com.s2C3S.utils.ParametersUtil;
import com.s2C3S.utils.WriteFileUtil;

import net.sf.javaml.classification.Classifier;

/**
 * @Description: A data stream without label information
 * @author Dr. Yunlong
 * @date Dec. 5, 2020
 */
public class UpdateNoLabCS {
	private ArrayList<Map<double[], Set<Integer>>> tConceptPoolList, gConceptPoolList;
	private List<double[]> errorIntentList;
	private Vector<Object> test_vec;
	private int[] train_Y;
	private Classifier classifier;
	private int index;

	public UpdateNoLabCS(int index, ArrayList<Map<double[], Set<Integer>>> tConceptPoolList,
			ArrayList<Map<double[], Set<Integer>>> gConceptPoolList, Classifier classifier, Vector<Object> test_vec,
			int[] train_Y) {
		this.index = index;
		this.tConceptPoolList = tConceptPoolList;
		this.gConceptPoolList = gConceptPoolList;
//		this.classifier = classifier;
		this.test_vec = test_vec;
		this.train_Y = train_Y;
	}

	@SuppressWarnings("unchecked")
	public void learningC3S() throws InterruptedException, ExecutionException, ClassNotFoundException, IOException {
		/** Load information */
		UpdateConceptSpace ucs = new UpdateConceptSpace();// load updating concept space function
		GetNewConcepts gnc = new GetNewConcepts();// load the method of getting new concepts.
		int batchSize = ParametersUtil.C;// load batch size

		/** Initial varies */
		double[][] test_X = (double[][]) test_vec.get(0);// data information
		int[] test_Y = (int[]) test_vec.get(1);// label information
		HashMap<Integer, Integer> classMap = (HashMap<Integer, Integer>) test_vec.get(2);// class information
		int calssNumber = classMap.size();
		int tempBatchsize = 0, epoch = 0;
		float corrSum = 0;
		ArrayList<Map<double[], Set<Integer>>> conceptSTM = new ArrayList<Map<double[], Set<Integer>>>();
		List<HashMap<Integer, double[]>> instanceList = new ArrayList<HashMap<Integer, double[]>>();// <No,attribute>
		List<Map<double[], Set<Integer>>> conceptList = new ArrayList<Map<double[], Set<Integer>>>();// <intent,extent>
		for (int i = 0; i < calssNumber; ++i) {// initial instanceList
			conceptSTM.add(new HashMap<double[], Set<Integer>>());// save current concepts,its size = 0.
			instanceList.add(new HashMap<Integer, double[]>());// instances-<No,attribute>
		} // end_of_for

		/**
		 * For a data stream: if C=1, forming a new concept and computing similarity; if
		 * C>1, forming new concepts and computing concept similarity in parallel.
		 */
		StringBuilder all_sb = new StringBuilder();
		StringBuilder all_sb2 = new StringBuilder();
		for (int rowN = 0; rowN < test_X.length; rowN++) {
			tempBatchsize++;
			/** For a batchSize, it will constructing concepts in parallel. */
			if (tempBatchsize == batchSize) {
				epoch++;// record the blocks.
				int correct = 0;
				double[][] bach_X = new double[batchSize][];// an array for batch instances.
				int[] bach_Y = new int[batchSize];// an array for batch instances.
				int rowStart = rowN + train_Y.length - batchSize + 1;// the begin number of new batch size.
				/** src=test_X, srcPos, dest=bach_X, destPos=0, length=batchSize */
				System.arraycopy(test_X, epoch * batchSize - batchSize, bach_X, 0, batchSize);// for instances
				System.arraycopy(test_Y, epoch * batchSize - batchSize, bach_Y, 0, batchSize);// for label information

				ForkJoinPool forkJoinPool = new ForkJoinPool();
				Future<Vector<Object>> future = forkJoinPool.submit(new ConComSimilarityByInsParLab(tConceptPoolList,
						gConceptPoolList, classifier, conceptSTM, bach_X, bach_Y, 0, batchSize, rowStart));
				Vector<Object> vec = future.get();
				correct = (int) vec.get(0);// get correct
				errorIntentList = (List<double[]>) vec.get(1);// get error concepts, its size = 0 without labels
				instanceList = (List<HashMap<Integer, double[]>>) vec.get(2);// get correct instances by class
				StringBuilder sb = (StringBuilder) vec.get(3);// get label information
				StringBuilder sb2 = (StringBuilder) vec.get(4);// get concept similarity and label information
				all_sb.append(sb);
				all_sb2.append(sb2);
				forkJoinPool.shutdown();

				/** Saves results by different batch size. */
				corrSum += (float) correct / batchSize;
				if (ParametersUtil.showResult.equals("bachSize")) {
					String fileName = "./data/Result[bachSize]_with_parLabel.txt";
					WriteFileUtil outFile = new WriteFileUtil(fileName);
					outFile.fileWriterLine((float) correct / batchSize + ",");
					System.out.println(
							"epoch--" + epoch + "--accSum--" + corrSum + "--acc--" + (float) correct / batchSize);
				} // end_of_if (ParametersUtil.showResult.equals("bachSize"))
			} // end_of_if (tempBatchsize == batchSize)

			/**
			 * Constructs new concepts; and then adds new concepts into original concept
			 * pools by batchSize directly. (1) For batchSize=1, it will add new concepts
			 * into pool directly; (2) For batchSize>1, it will update pool with removing
			 * errorIntentList and completing concept fusion process.
			 */
			if (tempBatchsize == batchSize) {
				conceptList = gnc.getNewConcepts(instanceList);// get new concepts.
				ucs.updateConceptList(tConceptPoolList, errorIntentList, conceptList);// correctConceptList
				tempBatchsize = 0; // initial to 0.
				instanceList.clear();// clear instances.
				for (int i = 0; i < calssNumber; ++i) {// initial instanceList
					instanceList.add(new HashMap<Integer, double[]>());
				} // end_of_for
			} // end_of_if
		} // end_of_for

		/** Saves label information. */
		String fileNameLabel = "D:/Labels/s2ConceptCS/Mnist/10%/Label" + index + ".csv";// 将其结果保存到文件中
//		String fileNameLabel = "D:/Labels/s2ConceptCS/HAR/20%/Label" + index + ".csv";// 将其结果保存到文件中
		WriteFileUtil outLabelFile = new WriteFileUtil(fileNameLabel);
		outLabelFile.fileWriter(all_sb.toString());
		String fileNameLabel2 = "D:/Labels/s2ConceptCS/Mnist/10%/simi_Label" + index + ".csv";// 将其结果保存到文件中
//		String fileNameLabel2 = "D:/Labels/s2ConceptCS/HAR/20%/simi_Label" + index + ".csv";// 将其结果保存到文件中
		WriteFileUtil outLabelFile2 = new WriteFileUtil(fileNameLabel2);
		outLabelFile2.fileWriter(all_sb2.toString());

		/** 将其结果保存到文件中:[所有块/总块数] */
		if (ParametersUtil.showResult.equals("overall")) {
			int chunk_num = test_Y.length / ParametersUtil.C;
			String fileName = "./data/Result[overall].txt";
			WriteFileUtil outFile = new WriteFileUtil(fileName);
			outFile.fileWriter((float) corrSum / chunk_num + ",");
			System.out.println("overallAcc--" + (float) corrSum / chunk_num + "--chunkNum--" + chunk_num);
		} // end_of_if (ParametersUtil.showResult.equals("overall"))
	}// end_of_learningC3S()
}
