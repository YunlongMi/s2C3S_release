package com.s2C3S.trainS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.s2C3S.utils.MathMethodUtil;
import com.s2C3S.utils.ParametersUtil;

/**
 * @author YunlongMi
 * @version V1.1
 * @date Jul. 16, 2020
 */
public class TrainCS {
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ArrayList<Map<double[], Set<Integer>>> trainingMethod(
			ArrayList<Map<double[], Set<Integer>>> conceptPoolList) {
		/** Concept fusion process */
		HashMap<double[], Set<Integer>> tempConceptMap = new HashMap<double[], Set<Integer>>();
		int count = 0;// record the number of radius
		for (int i = 0; i < conceptPoolList.size(); ++i) {// for each class
			/** Consider the size of each concept space being greater than the given size */
			if (conceptPoolList.get(i).size() >= ParametersUtil.conceptSZ) {// sets the initial size of each class
				List<double[]> keyList = new ArrayList(conceptPoolList.get(i).keySet());// gets intent list
				List<Set<Integer>> valueList = new ArrayList(conceptPoolList.get(i).values());// gets extent list
				for (int j = 0; j < keyList.size();) {
					double[] intent = keyList.get(j);// gets intent
					Set<Integer> extent = valueList.get(j);// gets extent
					Set<Integer> centerExtent = new TreeSet();// gets extent with a virtual null.
					/**
					 * For the virtual concepts (extent.size >1), it will be added into concept
					 * spaces directly; Otherwise, inner the range of radius, if the similarity
					 * degree between two instances is greater than the given value, a new concept
					 * will be produced. Then, for the rest of concepts, the same operation will be
					 * conducted until all instances is scanned. <br/>
					 */
					int k = j + 1;
					if (extent.size() > 1) {
						tempConceptMap.put(intent, extent);
					} else {
						/**
						 * 此处,k=j 用于实现对除去上一 radius 内所有概念之后,下一 radius 中概念进行学习. <br/>
						 * 后面的 j=j+count, 保证上一个 for 中的 j 也进行滑动 k 个大小.
						 */
						for (; k < keyList.size(); ++k) {
							double[] nextIntent = keyList.get(k);// gets the intent of the next concept
							Set<Integer> nextExtent = valueList.get(k);// gets the extent of the next concept
							double dist = MathMethodUtil.getCosineDistance(intent, nextIntent);
							/**
							 * Case 1: for k==(keyList.size()-1), the final instances; <br/>
							 * Case 2: for "count < radius", and "dist > the given value", constructing new
							 * concepts;<br/>
							 * Case 3: put the constructed concept into concept spaces.
							 */
							if (count < ParametersUtil.delta) {
								if (dist > ParametersUtil.r) {
									double[] aveIntent = MathMethodUtil.getAverageDistance(intent, nextIntent);
									// Set<Integer> unionExtent = MetricMethodUtil.getSetUnion(extent, nextExtent);
									intent = aveIntent;
									// extent = unionExtent;
									count++;
								} else {
									tempConceptMap.put(nextIntent, nextExtent);
								} // end_of_if
							} else {
								tempConceptMap.put(intent, centerExtent);
								break;
							} // end_of_if (count < ParametersUtil.radius)
						} // end_of_for (; k < keyList.size(); ++k)
						if (count < ParametersUtil.delta) {
							if (count == 0) {// 最后一块若没有可以融合的,则需直接加入
								tempConceptMap.put(intent, extent);
							} else {
								tempConceptMap.put(intent, centerExtent);
							}
						} // end_of_if (count < ParametersUtil.radius)
					} // end_of_if (extent.size() > 1)
					j = k;
					count = 0;
				} // end_of_for
				conceptPoolList.get(i).clear();
				conceptPoolList.get(i).putAll(tempConceptMap);
				tempConceptMap.clear();// clear the temporary concept space for next computing
			} // end_of_if
		} // end_of_for
		return conceptPoolList;
	}// end_of_trainingMethod
}
