package com.s2C3S.trainS;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ExecutionException;

import com.s2C3S.evaluateS.UpdateNoLabCS;
import com.s2C3S.initialS.InitalMethod;
import com.s2C3S.utils.ParametersUtil;

import net.sf.javaml.classification.Classifier;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.DefaultDataset;
import net.sf.javaml.core.DenseInstance;
import net.sf.javaml.core.Instance;
import net.sf.javaml.tools.weka.WekaClassifier;
import weka.classifiers.trees.RandomForest;

/**
 * @author YunlongMi
 * @version V1.1
 * @date Jul. 3, 2020
 * @details fastC3S
 */
public class s2C3S {
	private Vector<Object> train_vec, grow_vec;
	private Vector<Object> resVec; // It is as a global variable and input into evaluate method
	private ArrayList<Map<double[], Set<Integer>>> gConceptPoolList, tConceptPoolList;

	public s2C3S(Vector<Object> train_vec, Vector<Object> grow_vec) {
		this.train_vec = train_vec;
		this.grow_vec = grow_vec;
	}// end_of_CCCS

	/**
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 * @details Constructing concept spaces by means of selecting an theta.
	 */
	@SuppressWarnings("unchecked")
	public void initialS() throws IOException, InterruptedException, ExecutionException {
		InitalMethod IM = new InitalMethod(train_vec);// forms concept spaces based on a train dataset
		Vector<Object> vec = IM.initialConceptPoolByTheta();
		tConceptPoolList = (ArrayList<Map<double[], Set<Integer>>>) vec.get(0);// gets concept pool
		InitalMethod IMG = new InitalMethod(grow_vec);// forms concept spaces based on a grow dataset
		Vector<Object> vecG = IMG.initialConceptPoolByTheta();
		gConceptPoolList = (ArrayList<Map<double[], Set<Integer>>>) vecG.get(0);// gets concept pool

	}// end_of_initialS

	/**
	 * @param epochs
	 * @return
	 * @throws ExecutionException
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public Vector<Object> trainS()
			throws IOException, InterruptedException, ExecutionException, ClassNotFoundException {
		TrainCS tCS = new TrainCS();
		tConceptPoolList = tCS.trainingMethod(tConceptPoolList);
		gConceptPoolList = tCS.trainingMethod(gConceptPoolList);
		return resVec;
	}// end_of_train

	/**
	 * @param test_vec
	 * @param index 
	 * @throws ExecutionException
	 * @throws InterruptedException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @details Concept generalization
	 */
	public void evaluateS(Vector<Object> test_vec, int index)
			throws InterruptedException, ExecutionException, ClassNotFoundException, IOException {
		double[][] train_X = (double[][]) train_vec.get(0);// get instances
		int[] train_Y = (int[]) train_vec.get(1);// get labels

		Classifier classifier = null;
		if (!ParametersUtil.methodType.equals("conceptCS")) {
			Dataset data = new DefaultDataset();
			for (int i = 0; i < train_X.length; i++) {
				Instance instance = new DenseInstance(train_X[i], train_Y[i]);
				data.add(instance);
			}
			// Classifier m_classifier = new KNearestNeighbors(3);// classifier from Java-ML
			weka.classifiers.Classifier m_classifier = new RandomForest();
			classifier = new WekaClassifier(m_classifier);
			classifier.buildClassifier(data);
		} // end_of_if

		train_vec.clear();
		UpdateNoLabCS pC3S = new UpdateNoLabCS(index,tConceptPoolList, gConceptPoolList, classifier, test_vec, train_Y);
		pC3S.learningC3S();
		tConceptPoolList.clear();
		gConceptPoolList.clear();
		test_vec.clear();
	}// end_of_evaluate
}
